# Benchmark

One directory per problem:

```text
data/<problem id>/
  trajectories.jsonl   one trajectory per line: {problem_id, user_id, submissions: [{sid, ts, verdict, code}, ...]}
                       (two or more Wrong Answer submissions, then the student's first Accepted one)
  tests.jsonl          one test per line: {input, output}
  problem.html         problem statement
  meta.json            {time_limit_ms, memory_limit_kb}
```

14 AtCoder problems, 1,764 trajectories, 8,696 submissions (6,932 buggy). A trajectory is kept when the student made at
least two wrong-answer submissions, not all identical, before their first accepted one, every submission parses, and the
tests reproduce every verdict; a problem is kept when it has at least 100 such trajectories.

Sources: submissions, problem statements, and limits from Project CodeNet (https://github.com/IBM/Project_CodeNet,
Python800 benchmark); test cases from FixEval (https://github.com/mahimanzum/FixEval, AtCoder test cases). Both are
redistributed under the terms of their licenses.
