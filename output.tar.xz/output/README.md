# Outputs

The outputs behind every table and figure:

```text
output/
  approaches/  histra, refactory, brafar, lsgen (GPT-4o)      Fig. 1, Table II, Fig. 4, Fig. 5 (histra)
  ablation/    variants and controls of HISTRA (RQ3)         Table III, Fig. 5 (nohist)
  expert/      ratings.csv: the instructors' ratings (RQ4)   Fig. 5
```

Ablation: `nostd` (HISTRA-Norm), `nohole` (-Hole), `nokept` (-Kept), `plain` (-Min), `sizemin` (HISTRA_size),
`randhole0..2` (HISTRA_rand, three draws), `randfrac` (HISTRA_frac), `fl` (HISTRA_FL), `nohist` (HISTRA with H = {}).

Each technique has one file, `<name>.jsonl`, with one line per trajectory:

- `pid`, `user`; `was`: the wrong-answer submissions (`was[-1]` is the buggy program); `oracle`: the student's own
  accepted submission (used only for evaluation); `patch`: the repaired program (`null` if nothing passed all tests);
  `sec`: seconds; HISTRA rows also give the phase that produced the patch (`hole` or `free`).
- `skel_share`: the share of the buggy program in the intent skeleton; `ret_patch`, `ret_oracle`: the share of the
  skeleton that the patch and the student's own fix keep (skeleton loss = 1 - `ret_patch`).
- In `approaches/` also `kept` (Retained in the paper: of the buggy program's code that the student's own fix keeps, the share that the
  patch keeps) and `dist` (Dist: tree edit distance from the patch to the student's own fix).

`expert/ratings.csv` has one row per rated pair (`pid`, `user`): the patch each instructor chose as feedback and as
preserving the student's intent (`histra`, `nohist`, or `same`), before adjudication (`rater1_*`, `rater2_*`) and after
(`feedback`, `intent`).

`python run.py` writes `approaches/histra.jsonl` (`-m MODE`: `ablation/MODE.jsonl`), metrics included.
